# Lance toute l'analyse depuis la racine du projet
source("R/01_simuler_donnees.R")
source("R/02_modele_principal.R")
source("R/03_sensibilite.R")
